'fMRI_Examplar_TS.mat' contains an example of fMRI time series, encoded in the variable 'TS'.

'TS' has 114 lines corresponding to the Regions of Interest (Yeo et al., 2011) and 1200 time points.

Yeo, B.T.T. et al., 2011. The organization of the human cerebral cortex estimated by
intrinsic functional connectivity. J. Neurophysiol. 106, 1125-1165.
    